# Original Artifact

The initial version of this project was developed in my CS-360 course and functioned as a simple Android app for event management. Users could register, log in, and create, edit, or delete events displayed as a list on the main screen. The app also included basic SMS reminders to alert users on the day of each scheduled event. While it was functional, the original version offered numerous opportunities to enhance its structure, scalability, and user experience, making it an ideal candidate for upgrades.

___
###### amarkerr.github.io
